"""A simple Twitch chat bot that gives you the option to run complicated commands, to an extent that other bots don't allow."""
# __init__.py

__version__ = "1.2.11"
