permissions = {
    "on_permissions": {
        "all": "0",
        "uids": [],
        "badges": {
            "broadcaster": "1"
            },
        "forbid": {
            "all": "0",
            "uids": [],
            "badges": {}
            }
    },
    "on_channel": {
        "all": "0",
        "uids": [],
        "badges": {},
        "forbid": {
            "all": "0",
            "uids": [],
            "badges": {}
            }
    },
    "on_commadd": {
        "all": "0",
        "uids": [],
        "badges": {
            "broadcaster": "1"
            },
        "forbid": {
            "all": "0",
            "uids": [],
            "badges": {}
            }
    }
}
